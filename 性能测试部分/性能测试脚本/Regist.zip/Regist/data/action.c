Action()
{

	lr_think_time(18);

	web_submit_data("RegisterServlet", 
		"Action=http://localhost:8080/Timeline/RegisterServlet", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/Timeline/", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=RegUsername", "Value=tester1", ENDITEM, 
		"Name=RegPassword", "Value=tester1", ENDITEM, 
		"Name=RegPasswordCheck", "Value=tester1", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("registerSuccess.css", 
		"URL=http://localhost:8080/Timeline/css/registerSuccess.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://localhost:8080/Timeline/registerSuccess.jsp?id=381", 
		"Snapshot=t14.inf", 
		LAST);

	web_url("registerSuccess.js", 
		"URL=http://localhost:8080/Timeline/js/registerSuccess.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://localhost:8080/Timeline/registerSuccess.jsp?id=381", 
		"Snapshot=t15.inf", 
		LAST);

	web_concurrent_end(NULL);

	return 0;
}