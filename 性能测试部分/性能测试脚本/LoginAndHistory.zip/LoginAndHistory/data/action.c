Action()
{

	lr_think_time(25);

	lr_start_transaction("login");

	web_submit_data("LoginServlet", 
		"Action=http://localhost:8080/Timeline/LoginServlet", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/Timeline/", 
		"Snapshot=t6.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=logUsername", "Value=tester1", ENDITEM, 
		"Name=logPassword", "Value=tester1", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("home.css", 
		"URL=http://localhost:8080/Timeline/css/home.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("registerSuccess.css", 
		"URL=http://localhost:8080/Timeline/css/registerSuccess.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t8.inf", 
		LAST);

	web_url("home.js", 
		"URL=http://localhost:8080/Timeline/js/home.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t9.inf", 
		LAST);

	web_url("3.jpg", 
		"URL=http://localhost:8080/Timeline/img/3.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("7.jpg", 
		"URL=http://localhost:8080/Timeline/img/7.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t11.inf", 
		LAST);

	web_url("4.jpg", 
		"URL=http://localhost:8080/Timeline/img/4.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t12.inf", 
		LAST);

	web_url("5.jpg", 
		"URL=http://localhost:8080/Timeline/img/5.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t13.inf", 
		LAST);

	web_url("9.jpg", 
		"URL=http://localhost:8080/Timeline/img/9.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t14.inf", 
		LAST);

	web_url("10.jpg", 
		"URL=http://localhost:8080/Timeline/img/10.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("2.jpg", 
		"URL=http://localhost:8080/Timeline/img/2.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("1.jpg", 
		"URL=http://localhost:8080/Timeline/img/1.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t17.inf", 
		LAST);

	web_url("8.jpg", 
		"URL=http://localhost:8080/Timeline/img/8.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t18.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("login",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("history");

	web_url("GetInfoServlet", 
		"URL=http://localhost:8080/Timeline/GetInfoServlet?start=10", 
		"Resource=0", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t19.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("6.jpg", 
		"URL=http://localhost:8080/Timeline/img/6.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=860", 
		"Snapshot=t20.inf", 
		LAST);

	lr_end_transaction("history",LR_AUTO);

	return 0;
}