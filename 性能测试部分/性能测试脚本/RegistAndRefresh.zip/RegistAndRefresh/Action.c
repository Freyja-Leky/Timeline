Action()
{

	lr_think_time(22);

	lr_start_transaction("regist");

	web_submit_data("RegisterServlet", 
		"Action=http://localhost:8080/Timeline/RegisterServlet", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/Timeline/", 
		"Snapshot=t6.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=RegUsername", "Value={user}", ENDITEM, 
		"Name=RegPassword", "Value={user}", ENDITEM, 
		"Name=RegPasswordCheck", "Value={user}", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("registerSuccess.css", 
		"URL=http://localhost:8080/Timeline/css/registerSuccess.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://localhost:8080/Timeline/registerSuccess.jsp?id=859", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("registerSuccess.js", 
		"URL=http://localhost:8080/Timeline/js/registerSuccess.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://localhost:8080/Timeline/registerSuccess.jsp?id=859", 
		"Snapshot=t8.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("regist",LR_AUTO);

	web_url("home.jsp", 
		"URL=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/Timeline/registerSuccess.jsp?id=859", 
		"Snapshot=t9.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("home.css", 
		"URL=http://localhost:8080/Timeline/css/home.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("home.js", 
		"URL=http://localhost:8080/Timeline/js/home.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t11.inf", 
		LAST);

	web_url("3.jpg", 
		"URL=http://localhost:8080/Timeline/img/3.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t12.inf", 
		LAST);

	web_url("5.jpg", 
		"URL=http://localhost:8080/Timeline/img/5.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t13.inf", 
		LAST);

	web_url("4.jpg", 
		"URL=http://localhost:8080/Timeline/img/4.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t14.inf", 
		LAST);

	web_url("7.jpg", 
		"URL=http://localhost:8080/Timeline/img/7.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("8.jpg", 
		"URL=http://localhost:8080/Timeline/img/8.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("9.jpg", 
		"URL=http://localhost:8080/Timeline/img/9.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t17.inf", 
		LAST);

	web_url("10.jpg", 
		"URL=http://localhost:8080/Timeline/img/10.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t18.inf", 
		LAST);

	web_url("2.jpg", 
		"URL=http://localhost:8080/Timeline/img/2.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t19.inf", 
		LAST);

	web_url("1.jpg", 
		"URL=http://localhost:8080/Timeline/img/1.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t20.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(7);

	lr_start_transaction("refresh");

	web_url("home.jsp_2", 
		"URL=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/Timeline/registerSuccess.jsp?id=859", 
		"Snapshot=t21.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("style.css_2", 
		"URL=http://localhost:8080/Timeline/css/style.css", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t22.inf", 
		LAST);

	web_url("home.css_2", 
		"URL=http://localhost:8080/Timeline/css/home.css", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t23.inf", 
		LAST);

	web_url("registerSuccess.css_2", 
		"URL=http://localhost:8080/Timeline/css/registerSuccess.css", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t24.inf", 
		LAST);

	web_url("home.js_2", 
		"URL=http://localhost:8080/Timeline/js/home.js", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t25.inf", 
		LAST);

	web_url("3.jpg_2", 
		"URL=http://localhost:8080/Timeline/img/3.jpg", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t26.inf", 
		LAST);

	web_url("4.jpg_2", 
		"URL=http://localhost:8080/Timeline/img/4.jpg", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t27.inf", 
		LAST);

	web_url("7.jpg_2", 
		"URL=http://localhost:8080/Timeline/img/7.jpg", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t28.inf", 
		LAST);

	web_url("9.jpg_2", 
		"URL=http://localhost:8080/Timeline/img/9.jpg", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t29.inf", 
		LAST);

	web_url("8.jpg_2", 
		"URL=http://localhost:8080/Timeline/img/8.jpg", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t30.inf", 
		LAST);

	web_url("2.jpg_2", 
		"URL=http://localhost:8080/Timeline/img/2.jpg", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t31.inf", 
		LAST);

	web_url("10.jpg_2", 
		"URL=http://localhost:8080/Timeline/img/10.jpg", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t32.inf", 
		LAST);

	web_url("5.jpg_2", 
		"URL=http://localhost:8080/Timeline/img/5.jpg", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t33.inf", 
		LAST);

	web_url("1.jpg_2", 
		"URL=http://localhost:8080/Timeline/img/1.jpg", 
		"Resource=1", 
		"Referer=http://localhost:8080/Timeline/home.jsp?id=859", 
		"Snapshot=t34.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("refresh",LR_AUTO);

	return 0;
}