/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 911
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_url("Timeline", 
		"URL=http://localhost:8080/Timeline/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("style.css", 
		"URL=http://localhost:8080/Timeline/css/style.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://localhost:8080/Timeline/", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("index.css", 
		"URL=http://localhost:8080/Timeline/css/index.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://localhost:8080/Timeline/", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("login.js", 
		"URL=http://localhost:8080/Timeline/js/login.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://localhost:8080/Timeline/", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("login.png", 
		"URL=http://localhost:8080/Timeline/img/login.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://localhost:8080/Timeline/", 
		"Snapshot=t5.inf", 
		LAST);

	web_concurrent_end(NULL);

	return 0;
}
