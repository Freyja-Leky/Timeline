import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import bean.Info;
import bean.User;
import dao.InfoDao;

public class InfoDaoTest {

	private InfoDao infodao;
	
	public InfoDaoTest() {
		infodao = new InfoDao();
	}
	
	@Test
	public void select_latest_ten_info() {
		List<Info> realInfo = infodao.selectTen(0);
		
		User user = new User(3,"Yadeah He",null);
		Timestamp ts = new Timestamp(System.currentTimeMillis());  
        String tsStr = "2019-01-05 12:14:42";  
        try {  
            ts = Timestamp.valueOf(tsStr);  
        } catch (Exception e) {  
            e.printStackTrace();  
        }
		Info info1 = new Info(25, user, ts, "", null);
		
		User user2 = new User(5,"王黎琳",null);
		Timestamp ts2 = new Timestamp(System.currentTimeMillis());
		tsStr = "2018-12-23 19:38:09";
		try {  
            ts2 = Timestamp.valueOf(tsStr);  
        } catch (Exception e) {  
            e.printStackTrace();  
        }
		Info info2 = new Info(16, user2, ts2, "根据 ISO/IEC 25000，内部质量是指在特定的使用条件下，产品能够满足明示的和隐含的需求所明确具备能力的全部固有特性，体现了产品的内在质量。外部质量是指在特定的使用条件下，产品能够满足明示和隐含的需求的程度，是产品质量的外部（实际）表现。从上述定义可知，外部质量和内部质量模型基本一致", null);
		
		assertEquals(10, realInfo.size());
		
		Info real1 = realInfo.get(0);
		assertEquals(info1.getId(), real1.getId());
		assertEquals(info1.getUser().getId(), real1.getUser().getId());
		assertEquals(info1.getTime(), real1.getTime());
		assertEquals(info1.getText(), real1.getText());
		
		Info real2 = realInfo.get(9);
		assertEquals(info2.getId(), real2.getId());
		assertEquals(info2.getUser().getId(), real2.getUser().getId());
		assertEquals(info2.getTime(), real2.getTime());
		assertEquals(info2.getText(), real2.getText());
		assertEquals(8, real2.getPictures().size());
		assertEquals("img/5.jpg", real2.getPictures().get(0));
		assertEquals("img/7.jpg", real2.getPictures().get(7));
	}

}
