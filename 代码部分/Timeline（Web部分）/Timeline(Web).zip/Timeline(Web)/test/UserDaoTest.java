import static org.junit.Assert.*;

import org.junit.Test;

import bean.User;
import dao.UserDao;

public class UserDaoTest {
	
	private UserDao userdao;
	
	public UserDaoTest() {
		// TODO Auto-generated constructor stub
		userdao = new UserDao();
	}

	@Test
	public void select_name_heyadi_in_Chinese() {
		User realUser = userdao.selectByName("何雅迪");
		User expectUser = new User(1,"何雅迪","123456");
		assertEquals(expectUser.getId(), realUser.getId());
		assertEquals(expectUser.getUsername(), realUser.getUsername());
		assertEquals(expectUser.getPassword(), realUser.getPassword());
	}
	
	@Test
	public void select_name_hyd_in_letter() {
		User realUser = userdao.selectByName("hyd");
		User expectUser = new User(10,"hyd","123456");
		assertEquals(expectUser.getId(), realUser.getId());
		assertEquals(expectUser.getUsername(), realUser.getUsername());
		assertEquals(expectUser.getPassword(), realUser.getPassword());
	}
	
	@Test
	public void select_name_abcdefg() {
		User realUser = userdao.selectByName("abcdefg");
		User expectUser = null;
		assertEquals(expectUser, realUser);
	}
	
	@Test
	public void insert_exist_user_hyd() {
		User user = new User("何雅迪","123456");
		boolean realResult = userdao.insert(user);
		boolean expectResult = false;
		assertEquals(expectResult, realResult);
	}
	
	@Test
	public void insert_nonexist_user_abcdefg() {
		User user = new User("abcdefghijk","456789");
		boolean realResult = userdao.insert(user);
		boolean expectResult = true;
		assertEquals(expectResult, realResult);
		
		User realUser = userdao.selectByName("abcdefghijk");
		User expectUser = new User(26,"abcdefghijk","456789");
		assertEquals(expectUser.getId(), realUser.getId());
		assertEquals(expectUser.getUsername(), realUser.getUsername());
		assertEquals(expectUser.getPassword(), realUser.getPassword());
	}

}
