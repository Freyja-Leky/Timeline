/**
 * 
 */
function countDown(secs,surl){
	time.innerHTML = secs;
	secs--;
	if(secs >= 0)
		setTimeout("countDown("+secs+",'"+surl+"')",1000);
	else
		location.href=surl;
}