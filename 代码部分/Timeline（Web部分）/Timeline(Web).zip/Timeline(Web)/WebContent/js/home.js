/**
 * 
 */
function goTop() {
	document.body.scrollTop = 0;
}

function reloadPage(){
	  location.reload()
}