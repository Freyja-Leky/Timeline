/**
 * 
 */
addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);
function hideURLbar() {
	window.scrollTo(0, 1);
}

function changeText() {
	var checkbox = document.getElementById("a");
	var label = document.getElementById("start");
	if(checkbox.checked)
		label.innerHTML = "←go back";
	else
		label.innerHTML = "get start→";
}

function changeToRegister() {
	var p1 = document.getElementById("loginError1");
	var p2 = document.getElementById("loginError2");
	p1.style.display = "none";
	p2.style.display = "none";
	var p3 = document.getElementById("registerError3");
	p3.style.display="none";
	
	var login = document.getElementById("login");
	var register = document.getElementById("register");
	login.style.display = "none";
	register.style.display = "";
}

function changeToLogin() {
	var p1 = document.getElementById("loginError1");
	var p2 = document.getElementById("loginError2");
	p1.style.display = "none";
	p2.style.display = "none";
	var p3 = document.getElementById("registerError3");
	p3.style.display="none";
	
	var login = document.getElementById("login");
	var register = document.getElementById("register");
	login.style.display = "";
	register.style.display = "none";
}

function validRegister() {
	var pw1 = document.getElementById("RegPassword").value;
	var pw2 = document.getElementById("RegPasswordCheck").value;
	var p = document.getElementById("registerError4");
	if(pw1 != pw2) {
		p.style.display = "";
		return false;
	}
	return true;
}