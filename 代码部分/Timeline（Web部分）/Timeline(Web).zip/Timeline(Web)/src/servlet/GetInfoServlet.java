package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Info;
import bean.Time;
import dao.InfoDao;

/**
 * Servlet implementation class GetInfoServlet
 */
@WebServlet("/GetInfoServlet")
public class GetInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetInfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
		InfoDao getInfo = new InfoDao();
		List<Info> infos = getInfo.selectTen(Integer.parseInt(request.getParameter("start")));
		for (int i = 0; i < infos.size(); i++) {
			Info info = infos.get(i);
			String username = info.getUser().getUsername();
			Timestamp time = info.getTime();
			Time t = new Time();
			String showTime = t.getTime(time);
			String text = info.getText();
			List<String> pictures = info.getPictures();
			out.print("<div class=\"info\">" + 
						"<div class=\"username\">" + username + "</div>" +
						"<div class=\"time\">" + showTime + "</div>" + 
						"<div class=\"text\">");
			if(text != null && !text.equals(""))
				out.print("<div class=\"word\">" + text + "</div>");
			if(pictures != null) {
				out.print("<div class=\"picture\">");
				for(int j = 0; j < pictures.size(); j++)
					out.print("<image src=\"" + pictures.get(j) + "\" alt=\"loading image...\"\r\n" + 
							"						style=\"width:30%;height: 150px;margin:10px;\" />");
				out.print("</div>");
			}
			out.print("</div>");
			out.print("</div>");
		}
		
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
