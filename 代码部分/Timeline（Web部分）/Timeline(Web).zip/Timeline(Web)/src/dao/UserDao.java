package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.User;

public class UserDao {
	private final String table = "user";

	/**
	 * login select
	 * 
	 * @param user
	 */
	public User selectByName(String username) {
		User user = null;

		Connection conn = JDBCUtil.getConnection();
		String sql = "select * from " + table + " where username = '" + username + "'";
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			pstmt = (PreparedStatement) conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next())
				user = new User(rs.getInt(1), rs.getString(2), rs.getString(3));
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}

		return user;
	}

	/**
	 * register insert
	 * 
	 * @param user
	 */
	public boolean insert(User user) {
		boolean result = false;
		if (selectByName(user.getUsername()) == null) {
			Connection conn = JDBCUtil.getConnection();
			String sql = "insert into " + table + "(username,password) values(?,?)";
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			try {
				pstmt = (PreparedStatement) conn.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
				pstmt.setString(1, user.getUsername());
				pstmt.setString(2, user.getPassword());
				if(pstmt.executeUpdate() != 0) {
					rs = pstmt.getGeneratedKeys();
					if(rs.next())
						user.setId(rs.getInt(1));
				}
				result = true;
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				JDBCUtil.close(rs, pstmt, conn);
			}
		}
		return result;
	}
}
