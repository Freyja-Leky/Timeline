package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import bean.Info;
import bean.User;

public class InfoDao {
	private final String table1 = "user";
	private final String table2 = "info";
	private final String table3 = "picture";
	
	/**
	 * 
	 * get info select
	 * 
	 */
	public ArrayList<Info> selectTen(int start) {
		List<Info> infos = new ArrayList<Info>();
		
		Connection conn = JDBCUtil.getConnection();
		String sql = "select * from " + table1 + " natural join " + table2 + 
				" order by time desc limit " + start + ",10";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = (PreparedStatement) conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int userId = rs.getInt(1);
				String userName = rs.getString(2);
				User user = new User(userId,userName,null);
				int infoId = rs.getInt(4);
				Timestamp time = rs.getTimestamp(5);
				String text = rs.getString(6);
				List<String> pictures = selectFromTable2(infoId);
				Info info = new Info(infoId,user,time,text,pictures);
				infos.add(info);
			}
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		
		return (ArrayList<Info>)infos;
	}
	
	/**
	 * 
	 * get picture
	 * 
	 */
	private ArrayList<String> selectFromTable2(int infoId) {
		List<String> images = new ArrayList<String>();
		
		Connection conn = JDBCUtil.getConnection();
		String sql = "select * from " + table3 + " where infoId = " + infoId;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = (PreparedStatement) conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				String img = rs.getString(3);
				images.add(img);
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		
		return (ArrayList<String>)images;
	}
	
	/**
	 * 
	 * insert info into table1
	 * 
	 */
	public boolean insertIntoTable2(Info info) {
		boolean result = false;
		
		Connection conn = JDBCUtil.getConnection();
		String sql = "insert into " + table2 + "(userId,time,text) values (?,?,?)";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = (PreparedStatement) conn.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, info.getUser().getId());
			pstmt.setTimestamp(2, info.getTime());
			pstmt.setString(3, info.getText());

			if(pstmt.executeUpdate() != 0) {
				rs = pstmt.getGeneratedKeys();
				if(rs.next())
					info.setId(rs.getInt(1));
			}
			
			List<String> pictures = info.getPictures();
			if(pictures.size() > 0)
				result = insertIntoTable3(info);
			else
				result = true;

		} catch (SQLException e) {
			// TODO: handle exception
 			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		
		return result;
	}
	
	/**
	 * 
	 * insert picture
	 * 
	 */
	private boolean insertIntoTable3(Info info) {
		boolean result = false;
		
		Connection conn = JDBCUtil.getConnection();
		String sql = "insert into " + table3 + "(infoId,picture) values (?,?)"; 
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = (PreparedStatement) conn.prepareStatement(sql);
			pstmt.setInt(1, info.getId());
			
			List<String> pictures = info.getPictures();
			for(int i = 0; i < pictures.size(); i++) {
				String picture = pictures.get(i);
				pstmt.setString(2, picture);
				pstmt.executeUpdate();
			}
			
			result = true;
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		
		return result;
	}
	

}
