package bean;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class Info {
	private int id;
	private User user;
	private Timestamp time;
	private String text;
	private List<String> pictures;
	
	public Info() {
		super();
		pictures = new ArrayList<String>();
	}

	public Info(int id, User user, Timestamp time, String text, List<String> pictures) {
		super();
		this.id = id;
		this.user = user;
		this.time = time;
		this.text = text;
		this.pictures = pictures;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Timestamp getTime() {
		return time;
	}

	public void setTime(Timestamp time) {
		this.time = time;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<String> getPictures() {
		return pictures;
	}

	public void setPictures(List<String> pictures) {
		this.pictures = pictures;
	}
}
