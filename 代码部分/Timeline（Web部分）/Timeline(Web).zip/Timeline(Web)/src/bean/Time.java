package bean;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Time {
	public String getTime(Timestamp time) {
		Timestamp current = new Timestamp(System.currentTimeMillis());
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String returnTime = df.format(time);

		long delta = (current.getTime() - time.getTime()) / 1000; // 秒
		if (delta < 60)
			returnTime = delta + " seconds ago";
		else if (delta < 3600) {
			delta = delta / 60;
			returnTime = delta + " minutes ago";
		} else if (delta < 21600) {
			delta = delta / (60*60);
			returnTime = delta + " hours ago";
		}

		return returnTime;
	}

}
