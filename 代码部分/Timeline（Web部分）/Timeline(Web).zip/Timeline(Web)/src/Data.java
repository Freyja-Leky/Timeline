import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import bean.Info;
import bean.User;
import dao.InfoDao;

public class Data {
	
	public static void insertUser(int num) {
	}
	
	public static void insertInfo(int num) {
		Random r = new Random();
		
		InfoDao infoDao = new InfoDao();
		
		for(int i = 0; i < num; i++) {
			Info info = new Info();
			
			int userId = r.nextInt(8) + 1;
			User user = new User(userId, null, null);
			info.setUser(user);
			
			Timestamp time = new Timestamp(System.currentTimeMillis());
			time.setTime(time.getTime()-(10*60*1000)+(num*60*1000));
			info.setTime(time);
			
			String text = readText();
			info.setText(text);
			
			boolean hasPic = r.nextBoolean();
			if(hasPic) {
				List<String> pictures = new ArrayList<String>();
				int picNum = r.nextInt(10)+1;
				for(int j = 0; j < picNum; j++) {
					String picture = "img/" + (r.nextInt(10)+1) + ".jpg";
					pictures.add(picture);
				}
				info.setPictures(pictures);
			}
			
			infoDao.insertIntoTable2(info);
		}
	}
	
	public static String readText() {
		Random r = new Random();
		FileInputStream file = null;
		BufferedReader reader = null;
		InputStreamReader inputStreamReader = null;
		String content = "";
		String tempString = null;
		
		try {
			file = new FileInputStream("text/" + (r.nextInt(5)+1) + ".txt");
			inputStreamReader = new InputStreamReader(file,"GBK");
			reader = new BufferedReader(inputStreamReader);
			while((tempString = reader.readLine()) != null)
				content += tempString;
			reader.close();
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			if(reader != null) {
				try {
					reader.close();
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		}
		
		//System.out.println(content);
		return content;
	}
	
	public static void main(String args[]) {
		insertInfo(1);
	}

}
