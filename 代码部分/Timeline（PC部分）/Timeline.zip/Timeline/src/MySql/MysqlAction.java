package MySql;

import java.awt.Image;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;

import information.Information;

public class MysqlAction {
	Connection connect;
	Statement stmt;
	ResultSet rs;
	int informationNumber = 10;
	int IDposition;
	ImageIcon[] PICTURE;
	ResultSet rspicture;

	public void StartAction(Information[] infor) {
		loadJDBC();
		try {
			rs = stmt.executeQuery("select * from info natural join user Order By time Desc");
			int i = 0;
			while (rs.next() && i < 10) {
				infor[i] = new Information();
				infor[i].setThisID(rs.getInt("infoId"));
				infor[i].setID(rs.getInt("userId"));
				infor[i].setName(rs.getString("username"));
				infor[i].setTime(rs.getTimestamp("time"));
				infor[i].setText(rs.getString("text"));
				//infor[i].setPictureNumber(rs.getInt("PictureNumber"));
				getPicture(rs.getInt("userId"));
				infor[i].setPicture(PICTURE);
				IDposition = rs.getInt("infoId");
				i++;

			}
		} catch (Exception e) {
			System.out.print("Error loading Mysql Driver!");
			e.printStackTrace();
		}

	}

	public void update(Information[] infor) {
		loadJDBC();
		try {
			rs = stmt.executeQuery("select * from info natural join user Order By time Desc");
			int i = 0;
			while (rs.next() && i < 10) {
				infor[i] = new Information();
				infor[i].setThisID(rs.getInt("infoId"));
				infor[i].setID(rs.getInt("userId"));
				infor[i].setName(rs.getString("username"));
				infor[i].setTime(rs.getTimestamp("time"));
				infor[i].setText(rs.getString("text"));
				//infor[i].setPictureNumber(rs.getInt("PictureNumber"));
				getPicture(rs.getInt("userId"));
				infor[i].setPicture(PICTURE);
				IDposition = rs.getInt("infoId");
				i++;
			}
		} catch (Exception e) {
			System.out.print("Error loading Mysql Driver!");
			e.printStackTrace();
		}
	}

	public int wantMore(Information[] infor) {
		loadJDBC();
		int number=0;
		try {
			rs = stmt.executeQuery("select * from info natural join user Order By time Desc");

			int i = 0;
		    while (rs.next()) {
				if (rs.getInt("infoId") != IDposition) {
					continue;
				} else {
					break;
				}

			}
			rs.next();
			while (rs.next() && i < 10) {
				infor[i] = new Information();
				infor[i].setThisID(rs.getInt("infoId"));
				infor[i].setID(rs.getInt("userId"));
				infor[i].setName(rs.getString("username"));
				infor[i].setTime(rs.getTimestamp("time"));
				infor[i].setText(rs.getString("text"));
				//infor[i].setPictureNumber(rs.getInt("PictureNumber"));
				getPicture(rs.getInt("infoId"));
				infor[i].setPicture(PICTURE);
				IDposition = rs.getInt("infoId");
				
				//System.out.println(infor[i].getThisID());
				//System.out.println(infor[i].getID());
				//System.out.println(infor[i].getTime());
				
				
				i++;
				number++;
			}
			informationNumber = informationNumber + 10;
			
		} catch (Exception e) {
			System.out.print("Error loading Mysql Driver!");
			e.printStackTrace();
		}

		return number;
	}

	public void getPicture(int thisID) {
		PICTURE = null;
		loadJDBC();
		try {
			rspicture = stmt.executeQuery("select * from picture where infoId=" + thisID);
			int pictureNumber = 0;

			// 得到图片个数
			while (rspicture.next()) {
				pictureNumber++;
			}
			//System.out.println(pictureNumber);
			PICTURE = new ImageIcon[pictureNumber];
			rspicture = stmt.executeQuery("select * from picture where infoId=" + thisID);

			// 将图片存入数组
			int i = 0;
			while (rspicture.next() && i < pictureNumber) {
				String imgPath = rspicture.getString("picture");
				PICTURE[i] = new ImageIcon(imgPath);
				PICTURE[i] = new ImageIcon(PICTURE[i].getImage().getScaledInstance(100, 90, Image.SCALE_DEFAULT));
				i++;
			}

		} catch (Exception e) {
			System.out.print("Error loading Mysql Driver!");
			e.printStackTrace();
		}

	}

	public void loadJDBC() {
		try { // 加载MYSQL JDBC驱动程序
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Success loading Mysql Driver!");
		} catch (Exception e) {
			System.out.print("Error loading Mysql Driver!");
			e.printStackTrace();
		}
		try {
			connect=DriverManager.getConnection("jdbc:mysql://47.101.195.21:3306/timeline?characterEncoding=utf8","root","123456");
			//connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/timeline", "root", "peRFect0808");
			// 连接URL为 jdbc:mysql//服务器地址/数据库名 ，后面的2个参数分别是登陆用户名和密码
			System.out.println("Success connect Mysql server!");
			stmt = connect.createStatement();
		} catch (Exception e) {
			System.out.print("Error loading Mysql Driver!");
			e.printStackTrace();
		}
	}

	
}
