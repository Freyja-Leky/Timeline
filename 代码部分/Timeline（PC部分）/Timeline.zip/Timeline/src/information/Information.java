package information;

import java.sql.*;

import javax.swing.ImageIcon;

/*数据库设计
 * accountInformation   ID(int 10)  Name(varchar 8)  PassWord(varchar  16)   
 * newInformation  thisID(int 10)  ID(int 10)  Name(varchar 8)  Time(TimeStamp) 
 *                 Text(允许为空varchar 140)  PictureNumber(int 8)  
 * PictureTable   thisID(int 10)  Picture(MediumBlob)
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
public class Information {
	private int thisID;
	private int ID;
	private String name;
	private Timestamp time;
	private String text=null;
	//private int pictureNumber;
	//private String[] picturePosition;
	

	private ImageIcon[] picture;
	
	
	
	
	public int getThisID() {
		return thisID;
	}

	public void setThisID(int thisID) {
		this.thisID = thisID;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Timestamp getTime() {
		return time;
	}

	public void setTime(Timestamp time) {
		this.time = time;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public void setPicture(ImageIcon[] picture) {
		this.picture = picture;
		//this.picturePosition=picturePosition;
	}

	public ImageIcon[] getPicture() {
		return picture;
	}
	
	public Information() {
        
	}

}
