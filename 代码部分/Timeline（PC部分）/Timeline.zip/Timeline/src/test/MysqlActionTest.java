package test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Timestamp;

import org.junit.jupiter.api.Test;

import MySql.MysqlAction;
import information.Information;

class MysqlActionTest {
private MysqlAction mysqlActionTest;
	
	public MysqlActionTest() {
        // TODO Auto-generated constructor stub
        mysqlActionTest = new MysqlAction();
    }
	
	@Test
	void testStartAction() {
		 Information[] realInfo = new Information[10]; 
	     mysqlActionTest.StartAction(realInfo);
	        
	        Timestamp ts = new Timestamp(System.currentTimeMillis());  
	        String tsStr = "2019-01-04 22:14:42.0";  
	      
	            ts = Timestamp.valueOf(tsStr);  
	        Information info1 = new Information();
	        info1.setID(3);
	        info1.setThisID(25);
	        info1.setName("Yadeah He");
	        info1.setTime(ts);
	       
	        
	        assertEquals(10, realInfo.length);
	        
	        Information real1 = realInfo[0];
	       
	        assertEquals(info1.getID(), real1.getID());
	        assertEquals(info1.getThisID(), real1.getThisID());
	        assertEquals(info1.getTime(), real1.getTime());
	        
	        
	    
	}

	@Test
	void testUpdate() {
		 Information[] realInfo = new Information[10]; 
	     mysqlActionTest.update(realInfo);
	        
	        Timestamp ts = new Timestamp(System.currentTimeMillis());  
	        String tsStr = "2019-01-04 22:14:42.0";  
	      
	            ts = Timestamp.valueOf(tsStr);  
	        Information info1 = new Information();
	        info1.setID(3);
	        info1.setThisID(25);
	        info1.setName("Yadeah He");
	        info1.setTime(ts);
	       
	        
	        assertEquals(10, realInfo.length);
	        
	        Information real1 = realInfo[0];
	       
	        assertEquals(info1.getID(), real1.getID());
	        assertEquals(info1.getThisID(), real1.getThisID());
	        assertEquals(info1.getTime(), real1.getTime());
	        
	        
	    
	}

	@Test
	void testWantMore() {
		Information[] realInfo = new Information[10]; 
	     mysqlActionTest.wantMore(realInfo);
	        
	       
	     Timestamp ts = new Timestamp(System.currentTimeMillis());  
	        String tsStr = "2019-01-04 22:14:42.0";  
	      
	            ts = Timestamp.valueOf(tsStr);  
	        Information info1 = new Information();
	        info1.setID(3);
	        info1.setThisID(25);
	        info1.setName("Yadeah He");
	        info1.setTime(ts);
	     
	     
	        
	        assertEquals(10, realInfo.length);
	        
	        Information real1 = realInfo[0];
	        assertEquals(info1.getThisID(), real1.getThisID());
	        assertEquals(info1.getTime(), real1.getTime());
	        assertEquals(info1.getID(), real1.getID());
	        
	       
	}

	

}
