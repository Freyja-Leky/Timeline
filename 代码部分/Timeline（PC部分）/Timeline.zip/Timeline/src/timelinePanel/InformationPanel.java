package timelinePanel;

import javax.swing.*;

import information.Information;

public class InformationPanel extends JPanel{
	JLabel NAME;
	JLabel TIME;
	JLabel TEXT;
	JLabel PICTURE[];
	Interval interval;
	
	public InformationPanel() {
		NAME=new JLabel();
		TIME=new JLabel();
		TEXT=new JLabel();
		//PICTURE=new JLabel[9];
	}
	public InformationPanel(Information information) {
		interval=new Interval();
		NAME=new JLabel(information.getName());
		TIME=new JLabel(interval.getInterval(information.getTime().toString()));
		TEXT=new JLabel(information.getText());
		//PICTURE=new JLabel[9];
		//contextList[i] = new JPanel();
		//contextList[i].setLayout(null);
		this.setLayout(null);
		this.add(NAME);
		this.add(TIME);
		this.add(TEXT);
		NAME.setBounds(0, 0, 100, 20);
		TIME.setBounds(830, 0, 130, 20);
		TEXT.setBounds(0, 20, 1000, 100);
		
		int num=information.getPicture().length;
		PICTURE=new JLabel[num];
		//System.out.println(num);
		if(num!=0){
			for(int q=0;q<num;q++) {
				PICTURE[q]=new JLabel(information.getPicture()[q]);
				this.add(PICTURE[q]);
				PICTURE[q].setBounds(0+q*100, 100, 100, 90);
				
			}
	    }
	    
	}
	
		
		
}
