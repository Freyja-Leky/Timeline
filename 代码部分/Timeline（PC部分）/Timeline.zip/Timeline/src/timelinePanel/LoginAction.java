package timelinePanel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoginAction {
	Connection connect;
	Statement stmt;
	ResultSet rs;
	public void loadJDBC() {
		try { // 加载MYSQL JDBC驱动程序
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Success loading Mysql Driver!");
		} catch (Exception e) {
			System.out.print("Error loading Mysql Driver!");
			e.printStackTrace();
		}
		try {
			connect=DriverManager.getConnection("jdbc:mysql://47.101.195.21:3306/timeline?characterEncoding=utf8","root","123456");
			//connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/timeline", "root", "peRFect0808");
			// 连接URL为 jdbc:mysql//服务器地址/数据库名 ，后面的2个参数分别是登陆用户名和密码
			System.out.println("Success connect Mysql server!");
			stmt = connect.createStatement();
		} catch (Exception e) {
			System.out.print("Error loading Mysql Driver!");
			e.printStackTrace();
		}
	}
	
	public String login(String account, String password) {
		String result = "wrong password!";
		loadJDBC();
		try {
			rs = stmt.executeQuery("select * from user where username =\"" + account + "\"");

			if (rs.next()) {
				if (rs.getString("password").equals(password)) {
					result = "good!";
				} else {
					result = "wrong password!";
				}

			} else {
				result = "don't exist!";

			}
		} catch (Exception e) {
			System.out.print("Error loading Mysql Driver!");
			e.printStackTrace();
		}

		return result;
	}

	public String register(String account, String password1, String password2) {
		String result = null;
		loadJDBC();
		int bigID = 0;
		try {
			rs = stmt.executeQuery("select * from user");
			boolean flag = true;
			while (rs.next()) {
				if (rs.getString("username").equals(account)) {
					flag = false;
				}
				if (rs.getInt("userId") > bigID) {
					bigID = rs.getInt("userId");
				}
			}
			if (flag) {
				if (password1.equals(password2)) {
					// 写入记录
					bigID = bigID + 1;
					stmt.execute("insert into user(userId,username,password) values(" + bigID + ",\"" + account
							+ "\",\"" + password1 + "\")");
					result = "good!";
				} else {
					result = "wrong password!";
				}
			} else {
				result = "repeat!";

			}

		} catch (Exception e) {
			System.out.print("Error loading Mysql Driver!");
			e.printStackTrace();
		}

		return result;
	}
}
