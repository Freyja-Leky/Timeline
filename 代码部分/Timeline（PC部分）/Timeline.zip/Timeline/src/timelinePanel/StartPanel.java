package timelinePanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import MySql.MysqlAction;

public class StartPanel extends JFrame {// 起始登录界面

	// JLabel label;
	JLabel account;
	JLabel password;
	JButton login;
	JButton register;
	JTextField accountText;
	JPasswordField passwordValue;
	MysqlAction sql;
	LoginAction lo;

	public StartPanel() {

		// label = new JLabel();
		// label.setBounds(20, 150, 200, 50);

		passwordValue = new JPasswordField();
		passwordValue.setBounds(100, 75, 100, 30);

		account = new JLabel("账号:");
		account.setBounds(20, 20, 80, 30);

		password = new JLabel("密码:");
		password.setBounds(20, 75, 80, 30);

		login = new JButton("登录");
		login.setBounds(120, 120, 80, 30);

		register = new JButton("注册");
		register.setBounds(20, 120, 80, 30);

		accountText = new JTextField();
		accountText.setBounds(100, 20, 100, 30);

		this.add(account);
		this.add(password);
		this.add(accountText);
		this.add(passwordValue);

		this.add(login);
		this.add(register);

		this.setSize(300, 300);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String result = null;
				sql = new MysqlAction();
				lo=new LoginAction();
				String acc =accountText.getText();
				// data += ", 密码: " + new String(passwordValue.getPassword());
				String pas = new String(passwordValue.getPassword());
				result = lo.login(acc, pas);
				if (result.equals("good!")) {
					new TimelinePanel();
				} else if (result.equals("don't exist!")) {
					JOptionPane.showMessageDialog(null, "该用户不存在！", "登录失败！", JOptionPane.ERROR_MESSAGE);
				} else if (result.equals("wrong password!")) {
					JOptionPane.showMessageDialog(null, "密码错误！", "登录失败！", JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		register.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Register();

			}
		});

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new StartPanel();
	}

}
