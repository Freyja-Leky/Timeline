package timelinePanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import MySql.MysqlAction;

public class Register extends JFrame {
	// JLabel label;
		JLabel account;
		JLabel password;
		JLabel password2;
		JButton register;
		JTextField accountText;
		JPasswordField passwordValue;
		JPasswordField passwordValue2;
		MysqlAction sql;
        LoginAction lo;
		public Register() {

			// label = new JLabel();
			// label.setBounds(20, 150, 200, 50);

			passwordValue = new JPasswordField();
			passwordValue.setBounds(100, 75, 100, 30);
			
			passwordValue2=new JPasswordField();
			passwordValue2.setBounds(100, 130, 100, 30);
			

			account = new JLabel("账号:");
			account.setBounds(20, 20, 80, 30);

			password = new JLabel("密码:");
			password.setBounds(20, 75, 80, 30);
			
			password2=new JLabel("再次输入密码：");
			password2.setBounds(20,130,80,30);

			register = new JButton("确认注册");
			register.setBounds(100, 170, 100, 30);


			accountText = new JTextField();
			accountText.setBounds(100, 20, 100, 30);
			
			

			this.add(account);
			this.add(password);
			this.add(password2);
			this.add(accountText);
			this.add(passwordValue);
			this.add(passwordValue2);
			
		 	this.add(register);

			this.setSize(300, 300);
			this.setLocationRelativeTo(null);
			this.setLayout(null);
			this.setVisible(true);
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			register.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String result = null;
					sql = new MysqlAction();
					lo=new LoginAction();
					String acc =accountText.getText();
					// data += ", 密码: " + new String(passwordValue.getPassword());
					String pas1 = new String(passwordValue.getPassword());
					String pas2=new String(passwordValue2.getPassword());
					result = lo.register(acc, pas1,pas2);
					if (result.equals("good!")) {
						JOptionPane.showMessageDialog(null, "注册成功！", "恭喜注册成功！", JOptionPane.ERROR_MESSAGE);
						new TimelinePanel();
					} else if (result.equals("repeat!")) {
						JOptionPane.showMessageDialog(null, "用户名重复！", "注册失败！", JOptionPane.ERROR_MESSAGE);
					} else if (result.equals("wrong password!")) {
						JOptionPane.showMessageDialog(null, "两次密码不一致！", "注册失败！", JOptionPane.ERROR_MESSAGE);
					}
				}
			});

			

		}
}
