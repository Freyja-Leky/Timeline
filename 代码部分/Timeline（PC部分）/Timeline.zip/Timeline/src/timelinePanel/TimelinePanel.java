package timelinePanel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import MySql.MysqlAction;
import information.Information;

/*
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
public class TimelinePanel extends JFrame implements ActionListener {// Timeline主界面
	// 上层界面
	JPanel topInterface;// 上层界面
	JLabel name;// Timeline标题
	JButton update;// 更新
	// 滚动界面
	JScrollPane contextPanel;// 内容列表界面
	InformationPanel contextList[]; // 内容存储子界面
	JButton wantMore;// 更多
	JPanel centerPanel;

	// 数据存储区
	Information infor[];
	MysqlAction mysql;
	int inforNumber = 10;
	

	public TimelinePanel() {
		
		
		// 上层面板
		topInterface = new JPanel();
		name = new JLabel("Timeline", JLabel.CENTER);
		name.setFont(new Font("宋体", Font.PLAIN, 40));
		update = new JButton("更新");
		
		name.setBounds(0, 0, 500, 180);
		update.setBounds(600, 50, 100, 100);
		
		topInterface.setLayout(null);
		topInterface.add(name);
		topInterface.add(update);
		topInterface.setBounds(0, 0, 1000, 200);
		this.add(topInterface);

		// 滚动面板
		centerPanel = new JPanel();
		contextPanel = new JScrollPane(centerPanel, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		contextList = new InformationPanel[10];
		wantMore = new JButton("更多...");
		this.add(contextPanel);
		this.setBounds(500, 0, 1000, 830);
		contextPanel.setBounds(0, 200, 980, 600);
		centerPanel.setLayout(null);

		infor =new Information[10];
		for(int i=0;i<10;i++) {
			infor[i]=new Information();
			
		}
		
		// 数据库数据调用
		mysql = new MysqlAction();

		// 读取数据
		
		mysql.StartAction(infor);
		centerPanel.setPreferredSize(new Dimension(980, 2200));
		centerPanel.add(wantMore);
		//System.out.println(x);
		// 小面板的粘贴
		for (int i = 0; i < 10; i++) {
			
			contextList[i] = new InformationPanel(infor[i]);
			
			contextList[i].setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, Color.BLACK));
			contextList[i].setBounds(0, 200 * i, 980, 200);
			centerPanel.add(contextList[i]);

		}
		wantMore.setBounds(350, 2050, 200, 100);

		// 监听器
		update.addActionListener(this);
		wantMore.addActionListener(this);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		this.setVisible(true);
	}
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if (source == update) {
			mysql.update(infor);
			centerPanel.removeAll();
			centerPanel.add(wantMore);
			wantMore.setBounds(350, 2050, 200, 100);
			centerPanel.setPreferredSize(new Dimension(980, 2200));
			for (int i = 0; i < 10; i++) {
                this.remove(contextList[i]);
				contextList[i] = new InformationPanel(infor[i]);
				contextList[i].setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, Color.BLACK));
				contextList[i].setBounds(0, 200 * i, 980, 200);
				centerPanel.add(contextList[i]);

			}
			wantMore.setBounds(350, 2050, 200, 100);
			repaint();

		} else if (source == wantMore) {

			int number=mysql.wantMore(infor);
			Dimension dim=centerPanel.getPreferredSize();
			
			
			
			for (int i = 0; i <number; i++) {
				InformationPanel temp=new InformationPanel(infor[i]);
				temp.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, Color.BLACK));
				temp.setBounds(0, (int)dim.getHeight()+200 * (i-1), 980, 200);
				centerPanel.add(temp);

			}
			
			centerPanel.setPreferredSize(new Dimension(980,dim.height+200*number));
			dim=centerPanel.getPreferredSize();
			wantMore.setBounds(350, (int)dim.getHeight()-150, 200, 100);
			if(number==0) {
				JOptionPane.showMessageDialog(null, "没有更多啦！", "", JOptionPane.ERROR_MESSAGE);
			}
			repaint();
		}
	}

	/*public static void main(String[] args) {
		new TimelinePanel();
	}
	*/

}
